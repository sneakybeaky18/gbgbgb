# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

# Класс для определения структуры item'ов
class JobparserItem(scrapy.Item):
    # define the fields for your item here like:
    item_name = scrapy.Field()
    item_salary = scrapy.Field()
    description = scrapy.Field()
    location = scrapy.Field()
    website = scrapy.Field()
    _id = scrapy.Field()


