#Файл паука - парсит данные со страниц
import scrapy
from scrapy.http import HtmlResponse
from items import JobparserItem

class HhruSpider(scrapy.Spider):
    name = 'hhru'
    allowed_domains = ['hh.ru']   # Список разрешенных доменов
    start_urls = ['https://hh.ru/search/vacancy?clusters=true&enable_snippets=true&text=python&L_save_area=true&area=113&from=cluster_area&showClusters=true']

    # Метод parse является точкой входа. Он принимает response от get-запроса по ссылке в start_urls
    def parse(self, response:HtmlResponse):
        # Получаем список ссылок на вакансии на странице
        vacancies_links = response.xpath("//span/a[contains(@class,'bloko-link')]/@href").extract()
        for link in vacancies_links:  # Перебираем полученные ссылки
            yield response.follow(link, callback=self.vacansy_parse)

        # Ищем ссылку на след. страницу с вакансиями
        next_page = response.xpath("//a[contains(@class,'HH-Pager-Controls-Next')]/@href").extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse) # Рекурсия для повторной обработки страницы
        else:
            return  # Если ссылки на следю страницу не существует

    # Метод для обработки страницы с вакансией
    def vacansy_parse(self, response:HtmlResponse):
        description = response.xpath("//div[contains(@class,'g-user')]//text()").extract()
        name = response.xpath("//h1/text()").extract_first()
        salary = response.xpath("//p[@class='vacancy-salary']//text()").extract()
        location_web = response.xpath("//span[contains(@data-qa,'vacancy-view-raw-address')]//text()").extract()
        web = "hh.ru"
        yield JobparserItem(item_name=name, item_salary=salary, description=description, location=location_web, website=web)  # Передаем собранные данные в структуру items
