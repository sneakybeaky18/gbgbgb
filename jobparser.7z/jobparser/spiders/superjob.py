#Файл паука - парсит данные со страниц
import scrapy
from scrapy.http import HtmlResponse
from items import JobparserItem

class SuperJobSpider(scrapy.Spider):
    name = 'superjob'
    allowed_domains = ['superjob.ru']   # Список разрешенных доменов
    start_urls = ['https://www.superjob.ru/vacancy/search/?keywords=python&noGeo=1']

    # Метод parse является точкой входа. Он принимает response от get-запроса по ссылке в start_urls
    def parse(self, response:HtmlResponse):
        # Получаем список ссылок на вакансии на странице
        vacancies_links = response.xpath("//div[contains(@class,'_3mfro')]//a[contains(@target,'_blank')]/@href").extract()
        for link in vacancies_links:  # Перебираем полученные ссылки
            yield response.follow(link, callback=self.vacansy_parse)

        # Ищем ссылку на след. страницу с вакансиями
        next_page = response.xpath("//a[@rel='next']//@href").extract_first()
        if next_page:
            yield response.follow(next_page, callback=self.parse) # Рекурсия для повторной обработки страницы
        else:
            return  # Если ссылки на следю страницу не существует

    # Метод для обработки страницы с вакансией
    def vacansy_parse(self, response:HtmlResponse):
        description = response.xpath("//span[contains(@class,'_3mfro _2LeqZ _1hP6a _2JVkc _2VHxz _15msI')]//text()").extract()
        name = response.xpath('//h1[@class="_3mfro rFbjy s1nFK _2JVkc"]//text()').extract_first()
        salary = response.xpath("//span[@class='_1OuF_ ZON4b']//span//text()").extract()
        web = "superjob.ru"
        location_web = response.xpath("//div[contains(@class,'f-test-address')]//span[contains(@class,'_3mfro')]//text()").extract()
        yield JobparserItem(item_name=name, item_salary=salary, website=web, description=description, location=location_web)  # Передаем собранные данные в структуру items
